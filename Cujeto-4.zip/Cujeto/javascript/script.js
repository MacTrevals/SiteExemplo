
    <button onclick="clique_botao()">
    Pega no meu e balança
</button>
<p ondblclick="myFunction()"></p>Clique duas vezes nesse parágrafo</p>
<p id="dem"></p>



<script>
    function myFunction() {
        document.getElementId("dem").innerHTML = "HELL PUTA!";
    }
</script>
-->


<!----
<p id="dem"></p>
<script>
    document.getElementById("dem").innerHTML = "Sua segunda puta Js"; 
</script>
 -->
